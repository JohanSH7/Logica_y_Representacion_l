
package Reto3;

/**
 *
 * @author Escuiquirin
 */
public class Concesionario{
    
    public void venderCarro(){
    }

}
