package reto5;

/**
 *
 * @author Escuiquirin
 */
public class Charizard extends Pokemon {

    Charizard(String nombre, byte nivel, int salud) {
    }

    @Override
    public Pokemon evolucionar() {
        return null;
    }

    @Override
    String gritar() {
        return "Charizard!";
    }
    
}
