package reto5;

/**
 *
 * @author Escuiquirin
 */
public class Blastoise extends Pokemon {

    public Blastoise(String nombre, byte nivel, int salud) {
    }

    @Override
    public Pokemon evolucionar() {
        return null;
    }

    @Override
    String gritar() {
        return "Blastoise!";
    }
    
}
