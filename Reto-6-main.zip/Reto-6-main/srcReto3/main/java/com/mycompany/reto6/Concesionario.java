
package com.mycompany.reto6;

/**
 *
 * @author Escuiquirin
 */
public class Concesionario{
    
    public void venderCarro(){
    }

}
