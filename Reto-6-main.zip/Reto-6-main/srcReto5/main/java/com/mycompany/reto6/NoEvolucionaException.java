
package com.mycompany.reto6;

/**
 *
 * @author Johan.henao1
 */
public class NoEvolucionaException extends Exception {
    public NoEvolucionaException (){
        super ("Este pokemon no puede evolucionar más!");
    }
}
